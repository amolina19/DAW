<?php

    $colores = array(
        array("Rojo" => "FF0000","Verde" => "00FF00","Azul" => "0000FF"),
        array("Rosa" => "FE9ABC","Amarillo" => "FDF189","Malva" => "BC8F8F")
    );
    print_r($colores);
    
    
?>