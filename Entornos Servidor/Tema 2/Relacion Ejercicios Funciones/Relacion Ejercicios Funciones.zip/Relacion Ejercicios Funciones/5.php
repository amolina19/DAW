<?php

echo sumby2(5,7);
function sumby2($number1,$number2){
    return ($number1+$number2)/2;
}
?>