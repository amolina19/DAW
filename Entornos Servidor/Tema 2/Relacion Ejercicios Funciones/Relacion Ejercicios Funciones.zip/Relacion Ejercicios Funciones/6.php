<?php

echo text("Texto de prueba");
function text($text){
    return "<b>$text</b>";
}

?>