<?php

echo daysInt(20);

function daysInt($days){

    return (int)$days*24*3600;
}

?>
