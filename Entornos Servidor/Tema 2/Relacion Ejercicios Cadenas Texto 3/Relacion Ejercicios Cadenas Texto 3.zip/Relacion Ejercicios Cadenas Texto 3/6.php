<?php

    $cadena = "... Hola a todos ...";
    $reemplazar = array("."," ");
    $cadena = str_replace($reemplazar,"",$cadena);
    print("\n".$cadena);
    print("\n");
?>