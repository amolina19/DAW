<?php

    $cadena = "vamos al o'Briiiiiiiiiiian";
    $out = addcslashes($cadena,"eiou");
    print($out);
    
?>
