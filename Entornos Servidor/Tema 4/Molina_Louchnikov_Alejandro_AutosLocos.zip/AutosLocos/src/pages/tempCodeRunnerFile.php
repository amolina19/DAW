<?php
userCookieExists