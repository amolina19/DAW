function open34(){
    window.open("www.tab.com","Tab","width=600,heigth=300");
    alert("Window opened");
}