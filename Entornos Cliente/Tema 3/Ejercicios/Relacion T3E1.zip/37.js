function open37(){

    var w = screen.width;
    var h = screen.height;
    h = h/2;
    var conf = "width="+w+",height="+h;
    window.open("tab.com","Another tab",conf);
}